package Assignment_2_Exs_10;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class PersonProps1 {
       static String name="";
       static String gender="";
       static String age="";
       static String salary="";
       
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			InputStream in=new FileInputStream("./resources/PersonProps.properties");
			Properties prop=new Properties();
			prop.load(in);
			name=prop.getProperty("name");
			gender=prop.getProperty("gender");
			salary=prop.getProperty("salary");
			
			
			System.out.println(name);
			System.out.println(gender);
			System.out.println(salary);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
