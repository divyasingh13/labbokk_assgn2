package Assignment_2_Exs_11_exception;

public class MobileException extends Exception {

	public MobileException(String msg) {
		super(msg);
	}
	
}
