package Assignment_2_Exs_11.test;

import java.time.LocalDate;

import org.junit.Test;

import junit.framework.Assert;

import Assignment_2_Exs_11_Dao.*;
import Assignment_2_Exs_11_Bean.Mobiles;
import Assignment_2_Exs_11_Bean.PurchaseDetails;
import Assignment_2_Exs_11_exception.MobileException;

public class MobileTest {

	@Test
	public void testValidInsert(){
		PurchaseDetails s1= new PurchaseDetails();
		s1.setMobileId(1001);
		s1.setCname("Divya");
		s1.setMailId("divya@capgemini.com");
		s1.setPhoneNo("7053855190");
		s1.setPurchaseId(102);
		
		IMobileDao dao= new MobileDaoImpl();
		try {
			PurchaseDetails s=dao.addDetails(s1);
			Assert.assertNotSame(0,s.getMobileId());
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
	@Test(expected=MobileException.class)
	public void testInsertForInvalid() throws MobileException{
		PurchaseDetails s1= new PurchaseDetails();
		s1.setMobileId(10);
		s1.setCname("Divya");
		s1.setMailId("divya@capgemini.com");
		s1.setPhoneNo("7053855190");
		s1.setPurchaseId(102);
		IMobileDao dao= new MobileDaoImpl();
		PurchaseDetails s=dao.addDetails(s1);
	}
	
	
}
	
	
	
	
	
	