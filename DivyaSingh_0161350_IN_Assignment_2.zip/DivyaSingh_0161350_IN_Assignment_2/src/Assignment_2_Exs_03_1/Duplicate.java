package Assignment_2_Exs_03_1;
import java.util.LinkedHashSet;


public class Duplicate {
	
public Duplicate() {
	
}
public void rdisplay( String obj1){
	String str=obj1;
	char[] chars=str.toCharArray();
LinkedHashSet<Character> ss= new LinkedHashSet<>();

for(char c:chars){
	ss.add(c);
}

StringBuilder sb=new StringBuilder();
for(Character ch:ss){
	sb.append(ch);
}

System.out.println(sb);

}
}
