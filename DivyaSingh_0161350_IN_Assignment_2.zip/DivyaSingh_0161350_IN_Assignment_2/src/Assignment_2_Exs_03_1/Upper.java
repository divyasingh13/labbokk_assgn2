package Assignment_2_Exs_03_1;

public class Upper {
	String rr;
public Upper() {
	
}
public void replace(String obj1){
	rr = obj1;
     StringBuilder sb = new StringBuilder();
     for(int i=0;i<=rr.length()-1;i++){
          char c = rr.charAt(i);
          if(i%2==0){
             sb.append(String.valueOf(c).toUpperCase());
          } else {
             sb.append(String.valueOf(c));
          }
     }
     System.out.println(sb.toString()); 

}
}
