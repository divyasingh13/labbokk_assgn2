package Assignment_2_Exs_05_service;

import Assignment_2_Exs_05_Bean.Employee;



public class InsuranceService implements IEmployeeService{
	
	
	@Override
	public	String getInsuranceScheme(Employee emp){

		//String ret="";
		long sal= emp.getSalary();
		String des = emp.getDesignation();
		if((sal > 5000  && sal < 20000)  || des.equalsIgnoreCase("System Associate"))
			emp.setInsuranceScheme("Scheme C");
		//   ret= "Scheme C";
		   else if((sal>= 20000 && sal < 40000) || des.equalsIgnoreCase("Programmer"))
			   emp.setInsuranceScheme("Scheme B");
		//	ret = "Scheme B";
		
		else if (sal >40000 || des.equalsIgnoreCase("Manager"))
			emp.setInsuranceScheme("Scheme A");
		
		else if (sal <5000 || des.equalsIgnoreCase("Clerk"))
			emp.setInsuranceScheme("No scheme");
		
		else
			emp.setInsuranceScheme("Invalid");
		
		return emp.getInsuranceScheme();
	}

	}

	

	