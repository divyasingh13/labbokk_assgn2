package Assignment_2_Exs_02;

public class PersonalDetail {
	
	public static void main(String[] args) {
		
		System.out.println("Personal Details:");
		System.out.println("---------------------");
		System.out.println("First name: DIVYA");
		System.out.println("Last name: SINGH");
		System.out.println("Gender: M");
		System.out.println("Age: 22");
		System.out.println("Weight: 56.50");
	}
}
