package Assignment_2_Exs_04;

import java.util.Scanner;

public class SavingAccounts extends Account {
private final double minbalance ;
public SavingAccounts(long accnum, double balance, String name, float age){
	super(accnum, balance);
	minbalance= 500;
}
@Override
public boolean withDraw(double amt){
	if(getBalance()>= (amt+minbalance))
	setBalance(getBalance()-amt);
	else
		System.out.println("Cannot withdraw from your account "+getAccnum() );
	return true;
}
public static void main(String[] args) {
	SavingAccounts s1= new SavingAccounts(1234, 1000, "Sachin", 26);
	System.out.println("Enter the amount to be withdrawn: ");
	@SuppressWarnings("resource")
	Scanner sc= new Scanner(System.in);
	double amt= sc.nextInt();
	s1.withDraw(amt);
	System.out.println("Your current balance is: "+s1.getBalance());
}
}