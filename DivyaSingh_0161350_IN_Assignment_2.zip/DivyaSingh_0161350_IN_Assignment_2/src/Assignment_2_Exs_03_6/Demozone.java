package Assignment_2_Exs_03_6;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Scanner;


public class Demozone {
public void accept(){
	System.out.println("Enter zone id:");
	@SuppressWarnings("resource")
	Scanner sc = new Scanner(System.in);
	String str=sc.next();
	ZoneId zoneId=ZoneId.of(str);
	LocalDateTime localDateTime=LocalDateTime.now(zoneId);
	System.out.println(localDateTime);
}
	public static void main(String[] args) {
		Demozone dz=new Demozone();
		dz.accept();
		
	}

}
